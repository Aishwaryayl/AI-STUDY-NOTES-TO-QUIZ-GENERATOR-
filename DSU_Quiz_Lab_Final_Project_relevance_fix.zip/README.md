# AI Study Notes to Quiz Generator Using Generative AI and Large Language Models

**Dayananda Sagar University · Final project submission**

## Submission contents

- **app/** contains the runnable branded web application, backend, SQLite schema, test suite, sample PDF and DOCX files, and both model configurations. The trained FLAN-T5 parameters are in app/model/trained_review/.
- **model-development/** contains the executed notebook. It downloads and cleans SciQ, fine-tunes FLAN-T5 Small, evaluates accuracy on held-out questions, and verifies that its saved weights reload correctly.
- **dataset/** contains raw SciQ Parquet files, cleaned JSONL splits, and source information.
- **evaluation/** contains per-question predictions, training loss, accuracy tables, example generations, a chart, and application verification results.
- **PROJECT_REPORT.md** explains the design, measured results, and testing scope.

## Run the application

Install Python 3.10+ and Ollama. Start Ollama, open PowerShell in the extracted submission folder, and run:

    cd app
    python -m venv .venv
    .\.venv\Scripts\python.exe -m pip install -r requirements-review.txt
    ollama pull qwen2.5:1.5b
    .\.venv\Scripts\python.exe app.py

Open http://127.0.0.1:8765. Register a test student account, then upload a file from app/data/verification/ or try **Database management systems** as an online topic. Answer and submit the quiz, then open History. The first independent answer check downloads the FLAN-T5 base model if it is missing. Online research needs an internet connection.

Run the notebook separately in Jupyter to reproduce training. It writes new results to its own output directory. The application already contains the verified trained checkpoint from the reported run. Additional environment and Docker instructions are in app/README.md.
