"""Run the DSU Quiz Lab local development server."""
import os
from quizlab.web import create_app

app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "8765")), threaded=True)

