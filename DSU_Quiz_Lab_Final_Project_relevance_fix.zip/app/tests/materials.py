from io import BytesIO

import pymupdf
from docx import Document

NOTES = (
    "A relational database represents data as tables. Each table contains rows and columns. "
    "A primary key uniquely identifies a row in a table. A foreign key links a row to a referenced key in another table. "
    "A database index can speed up lookup operations. A transaction groups related database actions into a single unit. "
    "A rollback reverses the changes made by an uncommitted transaction. Normalization organizes tables to reduce redundant data. "
    "A view is a named query that presents data as a virtual table. A join combines rows from two tables by using a matching condition. "
    "A composite key uses more than one column. A query retrieves or changes data in a database."
)


def pdf_bytes():
    with pymupdf.open() as pdf:
        page = pdf.new_page()
        page.insert_textbox(pymupdf.Rect(45, 45, 550, 750), NOTES, fontsize=12)
        return pdf.tobytes()


def docx_bytes():
    doc = Document()
    for sentence in NOTES.split(". "):
        doc.add_paragraph(sentence.rstrip(".") + ".")
    output = BytesIO()
    doc.save(output)
    return output.getvalue()

