"""Integration checks use a model double unless QUIZ_TEST_LIVE=1."""
from contextlib import closing
from io import BytesIO
import logging
import json
import os
from pathlib import Path
import re
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from quizlab.documents import extract
from quizlab.engine import QuizEngine, Passage
from quizlab.web import create_app
from tests.materials import pdf_bytes, docx_bytes


MODEL_SAMPLE = dict(question="Which key uniquely identifies a table row?",
                    correct_answer="primary key",
                    distractors=["foreign key", "partition key", "sort key"],
                    quote="A primary key uniquely identifies a row in a table.",
                    explanation="The primary key identifies each row.")


def simulated_generation(_self, passages, count, topic="", difficulty="standard",
                        avoid_questions=None, avoid_answers=None):
    offset = len(avoid_questions or [])
    return [{"question": f"Integration question {offset + i}?", "options": ["A", "B", "C", "D"],
             "answer": i % 4, "quote": passages[0].text[:100], "explanation": "Review explanation.",
             "source": {"title": passages[0].title, "locator": passages[0].locator, "url": passages[0].url}}
            for i in range(count)]


def token(response):
    match = re.search(rb'name="csrf" value="([^"]+)"', response.data)
    assert match, response.status_code
    return match.group(1).decode()


class ApplicationTest(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.db = str(Path(self.folder.name) / "test.sqlite3")
        self.app = create_app({"TESTING": True, "SECRET_KEY": "unit-test-local-secret", "DATABASE": self.db,
                               "SESSION_COOKIE_SECURE": False,
                               "CHECKPOINT_REVIEW": False})
        self.client = self.app.test_client()

    def test_existing_database_migrates_for_saved_sources(self):
        legacy_db = str(Path(self.folder.name) / "legacy.sqlite3")
        with closing(sqlite3.connect(legacy_db)) as db:
            db.executescript("""
                CREATE TABLE student (
                    id INTEGER PRIMARY KEY, student_number TEXT UNIQUE, name TEXT,
                    email TEXT UNIQUE, password_hash TEXT, session_version INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT '2026-01-01T00:00:00Z'
                );
                CREATE TABLE quiz (
                    id TEXT PRIMARY KEY, student_id INTEGER REFERENCES student(id),
                    title TEXT NOT NULL, mode TEXT NOT NULL, difficulty TEXT NOT NULL,
                    model TEXT NOT NULL, questions TEXT NOT NULL, created_at TEXT DEFAULT '2026-01-01T00:00:00Z',
                    UNIQUE(id,student_id)
                );
            """)
        create_app({"TESTING": True, "SECRET_KEY": "migration-test-secret", "DATABASE": legacy_db,
                    "SESSION_COOKIE_SECURE": False, "CHECKPOINT_REVIEW": False})
        with closing(sqlite3.connect(legacy_db)) as db:
            columns = {row[1] for row in db.execute("PRAGMA table_info(quiz)")}
            tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertIn("source_id", columns)
        self.assertIn("quiz_source", tables)

    def register(self, client=None, student="DSU101", email="alex@example.edu"):
        client = client or self.client
        response = client.post("/register", data={"csrf": token(client.get("/register")), "number": student,
            "name": "Alex Student", "email": email, "password": "my-test-password-123"})
        self.assertEqual(response.status_code, 302)
        return response

    def create_quiz(self, mode, filename=None, data=None):
        path = f"/generate/{mode}"
        fields = {"csrf": token(self.client.get(path)), "count": "3", "difficulty": "standard"}
        if filename:
            fields["document"] = (BytesIO(data), filename)
        else:
            fields["topic"] = "Database management systems"
        response = self.client.post(path, data=fields)
        self.assertEqual(response.status_code, 303, response.get_data(as_text=True)[-2200:])
        return response.location

    def submit(self, url, correct=2):
        page = self.client.get(url)
        self.assertEqual(page.data.count(b'type="radio"'), 12)
        self.assertNotIn(b"Correct answer</dt>", page.data)
        identifier = url.rsplit("/", 1)[1]
        with closing(sqlite3.connect(self.db)) as db:
            items = json.loads(db.execute("SELECT questions FROM quiz WHERE id=?", (identifier,)).fetchone()[0])
        answers = {f"q{i}": str(item["answer"] if i < correct else (item["answer"] + 1) % 4)
                   for i, item in enumerate(items)}
        answers["csrf"] = token(page)
        return self.client.post(url, data=answers, follow_redirects=True)

    def test_auth_profile_and_csrf(self):
        self.assertEqual(self.client.get("/history").status_code, 302)
        self.assertEqual(self.client.post("/register", data={}).status_code, 400)
        self.register()
        self.assertIn(b"Welcome, Alex.", self.client.get("/").data)
        with closing(sqlite3.connect(self.db)) as db:
            digest = db.execute("SELECT password_hash FROM student").fetchone()[0]
        self.assertTrue(digest.startswith("scrypt:"))
        profile = self.client.get("/profile")
        self.assertIn(b"DSU101", profile.data)
        result = self.client.post("/profile", data={"csrf": token(profile), "name": "Alex Kumar",
            "email": "updated@example.edu", "current": "my-test-password-123", "password": "replacement-password-123"},
            follow_redirects=True)
        self.assertIn(b"Your profile was updated", result.data)
        self.client.post("/logout", data={"csrf": token(result)})
        self.assertEqual(self.client.get("/profile").status_code, 302)
        page = self.client.get("/login")
        failed = self.client.post("/login", data={"csrf": token(page), "email": "updated@example.edu",
                                                 "password": "my-test-password-123"})
        self.assertIn(b"Check your email and password", failed.data)
        success = self.client.post("/login", data={"csrf": token(failed), "email": "updated@example.edu",
                                                  "password": "replacement-password-123"})
        self.assertEqual(success.status_code, 302)

    def test_upload_extraction_and_validation(self):
        for name, content in [("notes.pdf", pdf_bytes()), ("notes.docx", docx_bytes())]:
            with self.subTest(name=name):
                found = extract(name, content)
                self.assertIn("A relational database represents data as tables.", found[0].text)
                self.assertTrue(found[0].locator)
        with self.assertRaises(ValueError):
            extract("not-a-document.pdf", b"garbage")
        with self.assertRaises(ValueError):
            extract("unsupported.txt", b"garbage")

    def test_grounding_rejects_invented_evidence(self):
        passage = Passage("Notes", "A primary key uniquely identifies a row in a table.", "Page 1")
        item = QuizEngine.validate(MODEL_SAMPLE, passage, set(), set(), 22)
        self.assertEqual(item["options"][item["answer"]], "primary key")
        repeated_concept = QuizEngine.validate(MODEL_SAMPLE, passage, set(), {"primary key"}, 23)
        self.assertEqual(repeated_concept["options"][repeated_concept["answer"]], "primary key")
        cloze = QuizEngine.cloze_question(passage.text, "primary key")
        repaired = QuizEngine.validate({**MODEL_SAMPLE, "question": cloze}, passage, set(), set(), 24)
        self.assertEqual(repaired["options"][repaired["answer"]], "primary key")
        self.assertIsNone(QuizEngine.cloze_question("� Compare encoder vs decoder.", "encoder"))
        self.assertIsNone(QuizEngine.cloze_question("The encoder receives a corrupted version of the text.", "receives"))
        with self.assertRaises(ValueError):
            QuizEngine.validate({**MODEL_SAMPLE, "correct_answer": "imaginary key"},
                                passage, set(), set(), 22)

    @patch("quizlab.web.research", return_value=[Passage("Scholarly source", "Source evidence. " * 20,
                                                       "Abstract", "https://doi.org/10.123/example")])
    @patch.object(QuizEngine, "generate", simulated_generation)
    def test_both_modes_history_scoring_and_owner_isolation(self, research_mock):
        self.register()
        count_page = self.client.get("/generate/document").data
        self.assertIn(b"5 questions", count_page)
        self.assertIn(b"10 questions", count_page)
        self.assertNotIn(b"8 questions", count_page)
        pdf = self.create_quiz("document", "class.pdf", pdf_bytes())
        docx = self.create_quiz("document", "class.docx", docx_bytes())
        topic = self.create_quiz("topic")
        research_mock.assert_called_once_with("Database management systems")
        for url, count, score in [(pdf, 2, b"66.7%"), (docx, 3, b"100.0%"), (topic, 1, b"33.3%")]:
            reviewed = self.submit(url, count)
            self.assertIn(score, reviewed.data)
            self.assertIn(b"Correct answer", reviewed.data)
        for url, repeat_count in ((pdf, 5), (topic, 10)):
            result_url = url.replace("/quiz/", "/result/")
            result_page = self.client.get(result_url)
            self.assertIn(b"Practice this source again", result_page.data)
            quiz_id = url.rsplit("/", 1)[1]
            with closing(sqlite3.connect(self.db)) as db:
                old_source_id = db.execute("SELECT source_id FROM quiz WHERE id=?", (quiz_id,)).fetchone()[0]
                old_questions = json.loads(db.execute("SELECT questions FROM quiz WHERE id=?", (quiz_id,)).fetchone()[0])
                saved_text = db.execute("SELECT passages FROM quiz_source WHERE id=?", (old_source_id,)).fetchone()[0]
            self.assertTrue(json.loads(saved_text))
            repeated = self.client.post(f"/quiz/{quiz_id}/another", data={
                "csrf": token(result_page), "count": str(repeat_count), "difficulty": "standard"
            })
            self.assertEqual(repeated.status_code, 303)
            repeated_id = repeated.location.rsplit("/", 1)[1]
            with closing(sqlite3.connect(self.db)) as db:
                new_source_id = db.execute("SELECT source_id FROM quiz WHERE id=?", (repeated_id,)).fetchone()[0]
                new_questions = json.loads(db.execute("SELECT questions FROM quiz WHERE id=?", (repeated_id,)).fetchone()[0])
            self.assertEqual(new_source_id, old_source_id)
            self.assertEqual(len(new_questions), repeat_count)
            self.assertNotEqual(new_questions[0]["question"], old_questions[0]["question"])
        research_mock.assert_called_once_with("Database management systems")
        self.assertIn(b"class.pdf", self.client.get("/history").data)
        self.assertIn(b"Average score", self.client.get("/").data)
        self.assertIn(b"Highest score", self.client.get("/").data)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute("SELECT count(*),sum(total),sum(correct) FROM attempt").fetchone(), (3, 9, 6))
        self.assertEqual(self.client.get(pdf).status_code, 302)
        other = self.app.test_client()
        self.register(other, "DSU202", "other@example.edu")
        self.assertNotIn(b"class.pdf", other.get("/history").data)
        self.assertEqual(other.get(pdf).status_code, 404)
        self.assertEqual(other.get(pdf.replace("/quiz/", "/result/")).status_code, 404)
        self.assertEqual(other.post(pdf, data={"csrf": token(other.get("/")), "q0": "1"}).status_code, 404)

    @unittest.skipUnless(os.getenv("QUIZ_TEST_LIVE") == "1", "requires Ollama and online research")
    def test_live_all_three_modes(self):
        self.register()
        if os.getenv("QUIZ_TRACE") == "1":
            logging.basicConfig(level=logging.WARNING)
            logging.getLogger("quizlab.engine").setLevel(logging.DEBUG)
        recorded = {}
        for filename, data in [("integration.pdf", pdf_bytes()), ("integration.docx", docx_bytes()), (None, None)]:
            print(f"\nGenerating live quiz: {filename or 'online topic'}", flush=True)
            url = self.create_quiz("document" if filename else "topic", filename, data)
            result = self.submit(url, 2)
            self.assertIn(b"66.7%", result.data)
            with closing(sqlite3.connect(self.db)) as db:
                quiz_id = url.rsplit("/", 1)[1]
                payload = db.execute("SELECT questions FROM quiz WHERE id=?", (quiz_id,)).fetchone()[0]
                recorded[filename or "online topic"] = json.loads(payload)
            if path := os.getenv("QUIZ_LIVE_RESULTS"):
                Path(path).write_text(json.dumps(recorded, ensure_ascii=False, indent=2), encoding="utf-8")
            if filename is None:
                self.assertRegex(result.data, rb'https://(?:openstax.org|doi.org|openalex.org)')
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM attempt").fetchone()[0], 3)



if __name__ == "__main__":
    unittest.main()


