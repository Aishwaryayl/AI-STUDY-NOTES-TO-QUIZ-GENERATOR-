# AI Study Notes to Quiz Generator Using Generative AI and Large Language Models (LLMs)

**Dayananda Sagar University · Quiz Lab**

Quiz Lab turns a student's PDF, DOCX, or academic topic into a source-backed multiple-choice quiz. Students register, generate a quiz, answer it, and review their scores and the supporting evidence. Each student sees their own records.

## Run locally

You need Python 3.10 or later, [Ollama](https://ollama.com/download), the Qwen2.5 1.5B model, and an internet connection for topic research. A machine with 8 GB RAM or more is recommended for running the model alongside the application.

From this folder, run the following in PowerShell. Replace the interpreter path with .venv/bin/python on macOS or Linux.

    python -m venv .venv
    .\.venv\Scripts\python.exe -m pip install -r requirements-review.txt
    ollama pull qwen2.5:1.5b
    .\.venv\Scripts\python.exe app.py

Start Ollama if it is not already running. Open http://127.0.0.1:8765 and create a student account. Choose **Study material** and upload an English, searchable PDF or DOCX. Choose **Research a topic** and enter an academic topic such as **Database management systems**. Choose the difficulty and question count, generate the quiz, submit it, and open **History** to review the saved attempt. Long CPU generations may take several minutes. The first load may take longer. Files are limited to 12 MB, PDFs to 120 pages, and extracted documents to 350,000 characters. Scanned PDFs need OCR before upload.

Student IDs and emails must be unique. Registration checks their format. It does not verify current enrollment or email ownership. Sign in with the email used during registration. Use the profile menu to update your name, email, or password. The default SQLite database and session signing key are created under instance/.

## LLMs used by the application

Ollama runs Qwen2.5 to generate quizzes from uploaded notes or retrieved online material. The bundled fine-tuned FLAN-T5 checkpoint independently selects an answer using the question, its options, and the stored evidence. Results show agreement or disagreement after the student submits the quiz. The score is based on the stored quiz key.

The first answer check may download the FLAN-T5 base weights. For an existing offline base model, set QUIZ_FLAN_BASE_MODEL to its local folder. Set QUIZ_CHECKPOINT_REVIEW=0 for an Ollama-only installation using requirements.txt. An unavailable review is marked in results and the quiz remains usable.

## What goes where

| Path | Purpose |
|---|---|
| app.py, quizlab/web.py | App entry point, student authentication, profile, quiz generation, scoring, and result routes |
| quizlab/schema.sql | SQLite student, quiz, attempt, and sign-in throttling tables |
| quizlab/documents.py | PDF and DOCX extraction with page or paragraph locations |
| quizlab/research.py | Live OpenStax section retrieval and OpenAlex scholarly search |
| quizlab/engine.py | Passage ranking, structured LLM calls, answer validation, and option randomization |
| quizlab/templates, quizlab/static | Responsive HTML, styles, and quiz progress behavior |
| data/verification, model | Sample study files, Ollama configuration, and fine-tuned checkpoint |
| tests | Integration, extraction and grounding tests |
| compose.yaml, Dockerfile, .env.example | Deployment and runtime configuration |

Flask keeps HTML forms and account isolation on the server. SQLite makes records durable without requiring a separate database server. PyMuPDF reads PDF pages and python-docx extracts Word paragraphs and tables. Ollama runs structured generation locally. OpenStax provides indexed textbook sections for matching computing topics, while OpenAlex broadens coverage through scholarly abstracts. The app stores questions, keys, evidence and submissions. It retains extracted text passages and retrieved topic sources under the student's account so another quiz can use the same source without another upload or search. It does not retain uploaded file binaries.

## Test

    .\.venv\Scripts\python.exe -m unittest discover -s tests -v

This checks registration, login, profile updates, CSRF, PDF and DOCX parsing, grounding validation, both quiz workflows, grading, persistence, and student-specific access. The fast suite substitutes the external model and research calls where needed. Run the live test after starting Ollama and downloading the model.

    $env:QUIZ_TEST_LIVE = '1'
    .\.venv\Scripts\python.exe -m unittest tests.test_application.ApplicationTest.test_live_all_three_modes -v

The live test generates and submits three new quizzes via PDF, DOCX and online topic. Each run uses a temporary database and test accounts.

## Deployment

The Docker configuration uses persistent volumes.

    docker compose up --build -d
    docker compose exec ollama ollama pull qwen2.5:1.5b

The Compose configuration binds the web port to localhost and leaves Ollama internal. For a university deployment place an HTTPS reverse proxy in front of the app, set QUIZ_SECRET and QUIZ_SECURE_COOKIE=1, and allow a request timeout appropriate for model generation. Sign-in cookies are HTTP-only and same-site. Back up the quiz_records volume using a SQLite-consistent snapshot. Use a single app deployment with a local SQLite volume. Multi-host deployment would require a shared production database and a model job queue. Review model and source licenses, the institution's student-data procedures, and enrollment verification before accepting university-wide accounts.

Configuration keys are documented in .env.example. The optional OPENALEX_API_KEY increases research quota. Do not put credentials in the notebook or a source archive. 






## University branding assets

The wordmark is from the [Dayananda Sagar University website](https://www.dsu.edu.in/templates/sj_university2/images/styling/default/logo.png). The Harohalli main campus background is an architectural rendering from the [DSU Library brochure](https://www.dsu.edu.in/images/Library/SOL/Library_Brochure_2024.pdf). Both images are served from the local static directory.
