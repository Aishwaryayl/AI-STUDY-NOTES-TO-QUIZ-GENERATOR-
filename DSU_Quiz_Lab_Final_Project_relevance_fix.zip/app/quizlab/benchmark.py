"""SciQ preprocessing and reproducible retrieval evaluation."""
from hashlib import sha256
import random
from pathlib import Path

import pandas as pd

from .engine import Passage, clean, contains, normalize, retrieve, retrieval_features


def prepare(paths):
    seen_questions, seen_passages = set(), set()
    datasets = {}
    for split in ("train", "validation", "test"):
        table = pd.read_parquet(paths[split]).fillna("")
        rows, split_passages = [], set()
        for index, row in table.iterrows():
            question = clean(str(row.question))
            support = clean(str(row.support))
            answer = clean(str(row.correct_answer))
            options = [answer] + [clean(str(row[f"distractor{i}"])) for i in range(1, 4)]
            key = normalize(question)
            digest = sha256(normalize(support).encode()).hexdigest()
            if (len(support.split()) < 20 or not key or len(set(map(normalize, options))) != 4
                    or any(not normalize(option) for option in options)
                    or not contains(support, answer) or key in seen_questions or digest in seen_passages):
                continue
            rng = random.Random(f"{split}-{index}")
            rng.shuffle(options)
            rows.append({"id": f"{split}-{index}", "split": split, "group": digest, "question": question,
                         "support": support, "option_a": options[0], "option_b": options[1],
                         "option_c": options[2], "option_d": options[3],
                         "answer": "ABCD"[options.index(answer)], "correct_text": answer})
            seen_questions.add(key)
            split_passages.add(digest)
        seen_passages.update(split_passages)
        datasets[split] = pd.DataFrame(rows)
    return datasets


def save_prepared(datasets, folder):
    folder = Path(folder)
    folder.mkdir(exist_ok=True, parents=True)
    for split, table in datasets.items():
        table.to_parquet(folder / f"{split}.parquet", index=False)


def candidate_groups(table, cap, candidates):
    articles = table.drop_duplicates("group").reset_index(drop=True)
    sample = articles.sample(n=min(cap, len(articles)), random_state=47)
    passages = articles[["group", "support"]].to_dict("records")
    for case in sample.itertuples():
        rng = random.Random(case.id)
        negatives = [p for p in rng.sample(passages, candidates) if p["group"] != case.group][:candidates-1]
        pool = [Passage("", p["support"], p["group"]) for p in negatives]
        pool.append(Passage("", case.support, case.group))
        rng.shuffle(pool)
        yield case, pool


def fit_retriever(train, cap=1800):
    import numpy as np

    features, labels = [], []
    for case, pool in candidate_groups(train, cap, 10):
        for passage in pool:
            features.append(retrieval_features(passage, case.question))
            labels.append(int(passage.locator == case.group))
    matrix = np.asarray(features, dtype=float)
    truth = np.asarray(labels, dtype=float)
    scales = matrix.std(axis=0)
    scales[scales == 0] = 1
    standardized = (matrix - matrix.mean(axis=0)) / scales
    design = np.column_stack([standardized, np.ones(len(standardized))])
    sample_weights = np.where(truth == 1, 0.5 / truth.mean(), 0.5 / (1 - truth.mean()))
    coefficients = np.zeros(design.shape[1])
    # Minimize class-balanced logistic loss with mildly regularized full-batch gradient descent.
    for _ in range(500):
        logits = np.clip((design * coefficients).sum(axis=1), -28, 28)
        residual = (1 / (1 + np.exp(-logits)) - truth) * sample_weights
        gradient = (design * residual[:, None]).mean(axis=0)
        gradient[:-1] += 0.0001 * coefficients[:-1]
        coefficients -= 0.24 * gradient
    weights = (coefficients[:-1] / scales).tolist()
    # The train set has no publisher titles. Preserve the application title prior.
    weights[-1] = 2 * max(0.01, weights[0])
    return weights, len(features)


def benchmark_retrieval(table, cap=350, candidates=12, weights=None):
    """Rank one known passage among same-split distractor passages."""
    rows = []
    methods = ("ordered", "ranked", "trained") if weights else ("ordered", "ranked")
    for test_case, pool in candidate_groups(table, cap, candidates):
        for method in methods:
            ranked = retrieve(pool, test_case.question, method, weights=weights)
            rank = next(i for i, p in enumerate(ranked, 1) if p.locator == test_case.group)
            rows.append({"id": test_case.id, "method": method, "rank": rank,
                         "recall_at_1": int(rank == 1), "recall_at_3": int(rank <= 3),
                         "reciprocal_rank": 1 / rank})
    return pd.DataFrame(rows)


def score_retrieval(rows):
    return rows.groupby("method").agg(
        cases=("id", "size"), recall_at_1=("recall_at_1", "mean"),
        recall_at_3=("recall_at_3", "mean"), mrr=("reciprocal_rank", "mean"),
    ).sort_values("mrr", ascending=False)


def check_outputs(items, passages, case):
    index = {(p.title, p.locator, p.url): p.text for p in passages}
    evaluations = []
    for number, item in enumerate(items, 1):
        source = item["source"]
        text = index[(source["title"], source["locator"], source["url"])]
        options = item["options"]
        evaluations.append({
            "case": case, "question_number": number,
            "four_distinct_options": len(options) == len(set(map(normalize, options))) == 4,
            "answer_in_range": 0 <= item["answer"] < 4,
            "quote_in_source": contains(text, item["quote"]),
            "answer_in_quote": contains(item["quote"], options[item["answer"]]),
        })
    return evaluations

