"""Dayananda Sagar University quiz application."""
from datetime import datetime, timedelta, timezone
from functools import wraps
import hmac
import json
import os
from pathlib import Path
import re
from secrets import token_urlsafe
import sqlite3
import time
from uuid import uuid4

from dotenv import load_dotenv
from flask import (Flask, abort, flash, g, redirect, render_template, request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

from .documents import MAX_BYTES, extract
from .engine import GenerationError, Passage, QuizEngine
from .research import research
from .checkpoint_review import CheckpointReviewer

ROOT = Path(__file__).resolve().parent.parent
DUMMY_PASSWORD = generate_password_hash(token_urlsafe(32))
EMAIL = re.compile(r"[A-Za-z0-9.!#$%&'*+/=?^_{}|~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+")
NUMBER = re.compile(r"[A-Za-z0-9-]{4,24}")


def connect(path):
    db = sqlite3.connect(path, timeout=15)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    return db


def create_app(settings=None):
    load_dotenv(ROOT / ".env")
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.getenv("QUIZ_SECRET"),
        DATABASE=os.getenv("QUIZ_DB", str(ROOT / "instance" / "quizlab.sqlite3")),
        MAX_CONTENT_LENGTH=MAX_BYTES + 128 * 1024,
        SESSION_COOKIE_SECURE=os.getenv("QUIZ_SECURE_COOKIE", "0") == "1",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        PERMANENT_SESSION_LIFETIME=8 * 3600,
        MODEL_CONFIG=os.getenv("QUIZ_MODEL_CONFIG", str(ROOT / "model" / "quiz_model.json")),
        CHECKPOINT_DIR=os.getenv("QUIZ_CHECKPOINT_DIR", str(ROOT / "model" / "trained_review")),
        CHECKPOINT_REVIEW=os.getenv("QUIZ_CHECKPOINT_REVIEW", "1") == "1",
    )
    app.config.update(settings or {})
    Path(app.config["DATABASE"]).parent.mkdir(parents=True, exist_ok=True)
    if not app.secret_key:
        keyfile = Path(app.config["DATABASE"]).with_name("session.key")
        try:
            with keyfile.open("x") as new_key:
                new_key.write(token_urlsafe(48))
        except FileExistsError:
            pass
        app.secret_key = keyfile.read_text().strip()
    with connect(app.config["DATABASE"]) as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript(Path(__file__).with_name("schema.sql").read_text(encoding="utf-8"))
        quiz_columns = {row["name"] for row in db.execute("PRAGMA table_info(quiz)")}
        if "source_id" not in quiz_columns:
            db.execute("ALTER TABLE quiz ADD COLUMN source_id TEXT REFERENCES quiz_source(id)")
        db.execute("CREATE INDEX IF NOT EXISTS quiz_student_source ON quiz(student_id,source_id,created_at DESC)")
    db.close()
    engine = QuizEngine.configured(app.config["MODEL_CONFIG"])
    reviewer = CheckpointReviewer(app.config["CHECKPOINT_DIR"])
    review_enabled = app.config["CHECKPOINT_REVIEW"] and reviewer.available

    def database():
        if "db" not in g:
            g.db = connect(app.config["DATABASE"])
        return g.db

    @app.teardown_appcontext
    def close_database(error=None):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    def csrf():
        if "csrf" not in session:
            session["csrf"] = token_urlsafe(32)
        return session["csrf"]

    app.jinja_env.globals["csrf"] = csrf

    @app.template_filter("date")
    def display_date(value):
        return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone(timedelta(hours=5, minutes=30))).strftime("%d %b %Y, %H:%M IST")

    @app.before_request
    def request_context():
        g.student = None
        if session.get("student"):
            g.student = database().execute("SELECT * FROM student WHERE id=?", (session["student"],)).fetchone()
            if not g.student or g.student["session_version"] != session.get("version"):
                g.student = None
                session.clear()
        if request.method == "POST":
            token = request.form.get("csrf", "")
            if not session.get("csrf") or not hmac.compare_digest(token.encode(), session["csrf"].encode()):
                abort(400, "The form expired. Go back, refresh the page, and try again.")

    @app.after_request
    def response_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; "
            "form-action 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'"
        )
        if request.endpoint != "static":
            response.headers["Cache-Control"] = "no-store"
        return response

    def protected(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            return view(*args, **kwargs) if g.student else redirect(url_for("login"))
        return wrapped

    def form(field):
        return request.form.get(field, "").strip()

    def valid_email(email):
        return len(email) <= 254 and EMAIL.fullmatch(email)

    def start_session(student):
        session.clear()
        session.permanent = True
        session.update(student=student["id"], version=student["session_version"])

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if g.student:
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            name, number, email = form("name"), form("number"), form("email").lower()
            password = request.form.get("password", "")
            if not 2 <= len(name) <= 80 or not NUMBER.fullmatch(number) or not valid_email(email):
                flash("Enter your name, a 4–24 character student ID, and a valid email.", "error")
            elif not 10 <= len(password) <= 128:
                flash("Use a password of 10–128 characters.", "error")
            else:
                try:
                    with database() as db:
                        identifier = db.execute(
                            "INSERT INTO student(student_number,name,email,password_hash) VALUES(?,?,?,?)",
                            (number, name, email, generate_password_hash(password)),
                        ).lastrowid
                    start_session({"id": identifier, "session_version": 0})
                    flash("Your student workspace is ready.", "success")
                    return redirect(url_for("dashboard"))
                except sqlite3.IntegrityError:
                    flash("An account already uses that email or student ID.", "error")
        return render_template("auth.html", register=True)

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if g.student:
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            email = form("email").lower()[:254]
            client = request.remote_addr or "unknown"
            password = request.form.get("password", "")
            now = int(time.time())
            db = database()
            with db:
                db.execute("DELETE FROM login_failure WHERE at<?", (now - 900,))
                pair, ip = db.execute(
                    "SELECT count(CASE WHEN email=? THEN 1 END),count(*) FROM login_failure WHERE client=?",
                    (email, client),
                ).fetchone()
            if pair >= 7 or ip >= 40:
                flash("Too many sign-in attempts. Try again in 15 minutes.", "error")
                return render_template("auth.html", register=False), 429
            student = db.execute("SELECT * FROM student WHERE email=?", (email,)).fetchone()
            digest = student["password_hash"] if student else DUMMY_PASSWORD
            if len(password) <= 128 and check_password_hash(digest, password) and student:
                with db:
                    db.execute("DELETE FROM login_failure WHERE email=? AND client=?", (email, client))
                start_session(student)
                return redirect(url_for("dashboard"))
            with db:
                db.execute("INSERT INTO login_failure VALUES(?,?,?)", (email, client, now))
            flash("Check your email and password and try again.", "error")
        return render_template("auth.html", register=False)

    @app.post("/logout")
    @protected
    def logout():
        session.clear()
        return redirect(url_for("login"))

    def attempts(limit, offset=0):
        return database().execute(
            """SELECT q.id,q.title,q.mode,a.correct,a.total,a.submitted_at,
                   round(100.0*a.correct/a.total,1) AS percentage
                   FROM attempt a JOIN quiz q ON q.id=a.quiz_id
                   WHERE a.student_id=? ORDER BY a.submitted_at DESC,q.id LIMIT ? OFFSET ?""",
            (g.student["id"], limit, offset),
        ).fetchall()

    @app.get("/")
    @protected
    def dashboard():
        db = database()
        stats = db.execute(
            """SELECT count(*) AS attempts, coalesce(round(avg(100.0*correct/total),1),0) AS average,
               coalesce(round(max(100.0*correct/total),1),0) AS highest,
               coalesce(sum(total),0) AS questions FROM attempt WHERE student_id=?""",
            (g.student["id"],),
        ).fetchone()
        drafts = db.execute(
            """SELECT id,title,created_at FROM quiz WHERE student_id=?
               AND NOT EXISTS(SELECT 1 FROM attempt WHERE quiz_id=quiz.id)
               ORDER BY created_at DESC LIMIT 5""", (g.student["id"],),
        ).fetchall()
        return render_template("dashboard.html", stats=stats, recent=attempts(6), drafts=drafts)

    @app.get("/history")
    @protected
    def history():
        page = min(max(1, request.args.get("page", 1, type=int)), 10000)
        rows = attempts(21, (page - 1) * 20)
        return render_template("history.html", rows=rows[:20], page=page, more=len(rows) > 20)

    @app.route("/profile", methods=["GET", "POST"])
    @protected
    def profile():
        if request.method == "POST":
            name, email = form("name"), form("email").lower()
            current = request.form.get("current", "")
            replacement = request.form.get("password", "")
            if not 2 <= len(name) <= 80 or not valid_email(email):
                flash("Enter a valid name and email.", "error")
            elif len(current) > 128 or not check_password_hash(g.student["password_hash"], current):
                flash("Enter your current password to update your account.", "error")
            elif replacement and not 10 <= len(replacement) <= 128:
                flash("The new password must contain 10–128 characters.", "error")
            else:
                pwhash = generate_password_hash(replacement) if replacement else g.student["password_hash"]
                version = g.student["session_version"] + 1
                try:
                    with database() as db:
                        changed = db.execute(
                            """UPDATE student SET name=?,email=?,password_hash=?,session_version=?
                               WHERE id=? AND session_version=?""",
                            (name, email, pwhash, version, g.student["id"], g.student["session_version"]),
                        ).rowcount
                    if not changed:
                        abort(409, "Your account changed in another session. Sign in again.")
                    start_session({"id": g.student["id"], "session_version": version})
                    flash("Your profile was updated.", "success")
                    return redirect(url_for("profile"))
                except sqlite3.IntegrityError:
                    flash("That email is already in use.", "error")
        return render_template("profile.html")

    @app.route("/generate/<mode>", methods=["GET", "POST"])
    @protected
    def generate(mode):
        if mode not in {"topic", "document"}:
            abort(404)
        if request.method == "POST":
            try:
                count = int(form("count"))
                difficulty = form("difficulty")
                if count not in {3, 5, 8, 10} or difficulty not in {"foundations", "standard", "advanced"}:
                    raise ValueError("Choose a supported question count and difficulty.")
                if mode == "document":
                    upload = request.files.get("document")
                    if not upload or not upload.filename:
                        raise ValueError("Select a PDF or DOCX document.")
                    passages = extract(upload.filename, upload.stream.read(MAX_BYTES + 1))
                    title, focus = passages[0].title[:180], form("focus")
                else:
                    title = focus = form("topic")
                    passages = research(title)
                if len(focus) > 120:
                    raise ValueError("Keep the focus to 120 characters or fewer.")
                questions = engine.generate(passages, count, focus, difficulty)
                if review_enabled:
                    try:
                        reviewer.annotate(questions)
                    except Exception:
                        app.logger.exception("Trained answer review was unavailable")
                        for question in questions:
                            question["checkpoint_review"] = {"status": "unavailable"}
                quiz_id = uuid4().hex
                source_id = uuid4().hex
                saved_passages = json.dumps([
                    {"title": passage.title, "text": passage.text,
                     "locator": passage.locator, "url": passage.url}
                    for passage in passages
                ], ensure_ascii=False)
                with database() as db:
                    db.execute("INSERT INTO quiz_source(id,student_id,title,mode,focus,passages) VALUES(?,?,?,?,?,?)",
                               (source_id, g.student["id"], title, mode, focus, saved_passages))
                    db.execute("INSERT INTO quiz(id,student_id,title,mode,difficulty,model,questions,source_id) VALUES(?,?,?,?,?,?,?,?)",
                               (quiz_id, g.student["id"], title, mode, difficulty, engine.config["model"],
                                json.dumps(questions, ensure_ascii=False), source_id))
                return redirect(url_for("take", quiz_id=quiz_id), code=303)
            except (ValueError, GenerationError) as error:
                flash(str(error), "error")
                return render_template("generate.html", mode=mode), 422
        return render_template("generate.html", mode=mode)

    @app.post("/quiz/<quiz_id>/another")
    @protected
    def another_quiz(quiz_id):
        quiz = owned_quiz(quiz_id)
        source = database().execute(
            "SELECT * FROM quiz_source WHERE id=? AND student_id=?",
            (quiz["source_id"], g.student["id"]),
        ).fetchone() if quiz["source_id"] else None
        if not source:
            flash("This older quiz has no saved source. Upload the document or enter the topic again.", "error")
            return redirect(url_for("result", quiz_id=quiz_id))
        try:
            count = int(form("count"))
            difficulty = form("difficulty")
            if count not in {5, 10} or difficulty not in {"foundations", "standard", "advanced"}:
                raise ValueError("Choose 5 or 10 questions and a supported difficulty.")
            previous_rows = database().execute(
                "SELECT questions FROM quiz WHERE student_id=? AND source_id=? ORDER BY created_at DESC",
                (g.student["id"], source["id"]),
            ).fetchall()
            previous = [question for row in previous_rows for question in json.loads(row["questions"])]
            passages = [Passage(**item) for item in json.loads(source["passages"])]
            questions = engine.generate(
                passages, count, source["focus"], difficulty,
                avoid_questions=[item["question"] for item in previous],
                avoid_answers=[item["options"][item["answer"]] for item in previous],
            )
            if review_enabled:
                try:
                    reviewer.annotate(questions)
                except Exception:
                    app.logger.exception("Trained answer review was unavailable")
                    for question in questions:
                        question["checkpoint_review"] = {"status": "unavailable"}
            new_id = uuid4().hex
            with database() as db:
                db.execute(
                    "INSERT INTO quiz(id,student_id,title,mode,difficulty,model,questions,source_id) VALUES(?,?,?,?,?,?,?,?)",
                    (new_id, g.student["id"], source["title"], source["mode"], difficulty,
                     engine.config["model"], json.dumps(questions, ensure_ascii=False), source["id"]),
                )
            return redirect(url_for("take", quiz_id=new_id), code=303)
        except (ValueError, GenerationError) as error:
            flash(str(error), "error")
            return redirect(url_for("result", quiz_id=quiz_id))

    def owned_quiz(quiz_id):
        row = database().execute("SELECT * FROM quiz WHERE id=? AND student_id=?",
                                 (quiz_id, g.student["id"])).fetchone()
        if not row:
            abort(404)
        return row

    def saved_attempt(quiz_id):
        return database().execute("SELECT * FROM attempt WHERE quiz_id=? AND student_id=?",
                                  (quiz_id, g.student["id"])).fetchone()

    @app.route("/quiz/<quiz_id>", methods=["GET", "POST"])
    @protected
    def take(quiz_id):
        quiz = owned_quiz(quiz_id)
        if saved_attempt(quiz_id):
            return redirect(url_for("result", quiz_id=quiz_id))
        questions = json.loads(quiz["questions"])
        if request.method == "POST":
            answers = [request.form.get(f"q{i}") for i in range(len(questions))]
            if any(answer not in {"0", "1", "2", "3"} for answer in answers):
                flash("Select an answer for every question before submitting.", "error")
            else:
                chosen = list(map(int, answers))
                correct = sum(question["answer"] == answer for question, answer in zip(questions, chosen))
                with database() as db:
                    db.execute(
                        """INSERT INTO attempt(quiz_id,student_id,answers,total,correct)
                           VALUES(?,?,?,?,?) ON CONFLICT(quiz_id) DO NOTHING""",
                        (quiz_id, g.student["id"], json.dumps(chosen), len(questions), correct),
                    )
                return redirect(url_for("result", quiz_id=quiz_id), code=303)
        return render_template("take.html", quiz=quiz, questions=questions)

    @app.get("/result/<quiz_id>")
    @protected
    def result(quiz_id):
        quiz = owned_quiz(quiz_id)
        attempt = saved_attempt(quiz_id)
        if not attempt:
            return redirect(url_for("take", quiz_id=quiz_id))
        review = list(zip(json.loads(quiz["questions"]), json.loads(attempt["answers"])))
        can_reuse_source = bool(quiz["source_id"]) and database().execute(
            "SELECT 1 FROM quiz_source WHERE id=? AND student_id=?",
            (quiz["source_id"], g.student["id"]),
        ).fetchone()
        return render_template("result.html", quiz=quiz, attempt=attempt, review=review,
                               percentage=round(attempt["correct"] * 100 / attempt["total"], 1),
                               can_reuse_source=bool(can_reuse_source))

    @app.errorhandler(400)
    @app.errorhandler(404)
    @app.errorhandler(409)
    @app.errorhandler(413)
    @app.errorhandler(500)
    def handle_error(error):
        messages = {404: "This page or quiz is unavailable.", 413: "Upload a document up to 12 MB.",
                    500: "The request could not be completed. Try again."}
        return render_template("error.html", code=error.code,
                               message=messages.get(error.code, error.description)), error.code

    return app

