PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS student (
    id INTEGER PRIMARY KEY,
    student_number TEXT NOT NULL COLLATE NOCASE UNIQUE,
    name TEXT NOT NULL,
    email TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_hash TEXT NOT NULL,
    session_version INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS quiz_source (
    id TEXT PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES student(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    mode TEXT NOT NULL CHECK(mode IN ('document','topic')),
    focus TEXT NOT NULL DEFAULT '',
    passages TEXT NOT NULL CHECK(json_valid(passages)),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    UNIQUE(id,student_id)
);
CREATE TABLE IF NOT EXISTS quiz (
    id TEXT PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES student(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    mode TEXT NOT NULL CHECK(mode IN ('document','topic')),
    difficulty TEXT NOT NULL CHECK(difficulty IN ('foundations','standard','advanced')),
    model TEXT NOT NULL,
    questions TEXT NOT NULL CHECK(json_valid(questions)),
    source_id TEXT REFERENCES quiz_source(id),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    UNIQUE(id,student_id)
);
CREATE TABLE IF NOT EXISTS attempt (
    quiz_id TEXT PRIMARY KEY,
    student_id INTEGER NOT NULL,
    answers TEXT NOT NULL CHECK(json_valid(answers)),
    total INTEGER NOT NULL CHECK(total>0),
    correct INTEGER NOT NULL CHECK(correct>=0 AND correct<=total),
    submitted_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    FOREIGN KEY(quiz_id,student_id) REFERENCES quiz(id,student_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS quiz_student_created ON quiz(student_id,created_at DESC);
CREATE INDEX IF NOT EXISTS attempt_student_time ON attempt(student_id,submitted_at DESC);
CREATE TABLE IF NOT EXISTS login_failure (
    email TEXT NOT NULL,
    client TEXT NOT NULL,
    at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS login_failures_time ON login_failure(at);

