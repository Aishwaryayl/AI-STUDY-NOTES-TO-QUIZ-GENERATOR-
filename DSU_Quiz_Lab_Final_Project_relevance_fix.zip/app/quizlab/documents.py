"""Bounded in-memory extraction for text-based PDF and DOCX."""
from io import BytesIO
from pathlib import Path
from zipfile import BadZipFile, ZipFile

import pymupdf
from docx import Document
from docx.opc.exceptions import PackageNotFoundError
from lxml.etree import XMLSyntaxError

from .engine import chunk


MAX_BYTES = 12 * 1024 * 1024
MAX_TEXT = 350_000


def extract(filename, content):
    name = Path(filename.replace("\\", "/")).name
    suffix = Path(name).suffix.lower()
    if not 0 < len(content) <= MAX_BYTES:
        raise ValueError("Upload a document up to 12 MB.")
    try:
        if suffix == ".pdf":
            with pymupdf.open(stream=content, filetype="pdf") as doc:
                if doc.needs_pass:
                    raise ValueError("Use an unlocked PDF.")
                if len(doc) > 120:
                    raise ValueError("Upload a PDF with 120 pages or fewer.")
                pages = [(f"Page {i}", page.get_text(sort=True)) for i, page in enumerate(doc, 1)]
        elif suffix == ".docx":
            with ZipFile(BytesIO(content)) as archive:
                entries = archive.infolist()
                if len(entries) > 1500 or sum(item.file_size for item in entries) > 48 * 1024 * 1024:
                    raise ValueError("The DOCX expands beyond the supported size.")
            doc = Document(BytesIO(content))
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            pages = [(f"Paragraphs {i + 1}–{min(i + 8, len(paragraphs))}",
                      "\n".join(paragraphs[i:i + 8])) for i in range(0, len(paragraphs), 8)]
            for number, table in enumerate(doc.tables, 1):
                text = "\n".join(" | ".join(c.text for c in row.cells) for row in table.rows)
                pages.append((f"Table {number}", text))
        else:
            raise ValueError("Choose a PDF or DOCX file.")
    except (pymupdf.FileDataError, BadZipFile, PackageNotFoundError, XMLSyntaxError, KeyError, TypeError, OSError) as error:
        raise ValueError("The document cannot be read. Check the file format and try again.") from error

    if sum(len(text) for _, text in pages) > MAX_TEXT:
        raise ValueError("The extracted text is too long. Upload a chapter or shorter excerpt.")
    passages = [part for locator, text in pages for part in chunk(name, text, locator)]
    if sum(len(text.split()) for _, text in pages) < 50 or not passages:
        raise ValueError("At least 50 readable words are needed. Scanned PDFs need OCR before upload.")
    return passages

