const generationForm = document.querySelector("[data-generate]");
if (generationForm) {
  generationForm.addEventListener("submit", () => {
    generationForm.querySelector("button").disabled = true;
    generationForm.querySelector("[data-status]").hidden = false;
  });
}
const quiz = document.querySelector("[data-quiz]");
if (quiz) {
  const questions = Array.from(quiz.querySelectorAll("fieldset"));
  const jumps = quiz.querySelectorAll("[data-jump]");
  const update = () => {
    let done = 0;
    questions.forEach((question, index) => {
      const selected = Boolean(question.querySelector("input:checked"));
      if (selected) done += 1;
      jumps[index].classList.toggle("answered", selected);
    });
    quiz.querySelector("[data-progress]").textContent = done + " of " + questions.length + " answered";
  };
  quiz.addEventListener("change", update);
  update();
}
