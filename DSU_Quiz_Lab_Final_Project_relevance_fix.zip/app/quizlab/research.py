"""Retrieve current topic material from textbooks and scholarly works."""
from concurrent.futures import ThreadPoolExecutor
import os
from urllib.parse import urlparse

from bs4 import BeautifulSoup
import requests

from .engine import chunk, normalize, GenerationError


BOOK = "https://openstax.org/books/introduction-computer-science/pages/"
INDEX = [
    ("machine learning artificial intelligence ai data science deep learning neural network",
     "8-6-data-management-for-shallow-and-deep-learning-applications"),
    ("database dbms sql normalization relational database management primary foreign key",
     "8-3-relational-database-management-systems"),
    ("data science analytics data management database storage", "8-1-data-management-focus"),
    ("computer network networking information technology computing", "1-1-computer-science"),
    ("algorithm algorithms data structure stack queue trees sorting",
     "3-1-introduction-to-data-structures-and-algorithms"),
    ("operating system cpu computer architecture organization hardware processor",
     "5-1-computer-systems-organization"),
]
HEADERS = {"User-Agent": "DSUQuizLab/1.0 (academic study quiz retrieval)"}


def textbook(topic):
    terms = set(normalize(topic).split()) - {"and", "of", "the", "to"}
    match = sorted(INDEX, key=lambda entry: -len(terms & set(entry[0].split())))
    output = []
    for terms_label, slug in match[:2]:
        if not terms or len(terms & set(terms_label.split())) / len(terms) < 0.6:
            continue
        url = BOOK + slug
        try:
            response = requests.get(url, headers=HEADERS, timeout=(5, 12))
            response.raise_for_status()
        except requests.RequestException:
            continue
        soup = BeautifulSoup(response.text, "html.parser")
        main = soup.select_one("[data-type=page]") or soup.find("main")
        if not main:
            continue
        heading = main.find(["h1", "h2"])
        title = heading.get_text(" ", strip=True) if heading else slug.replace("-", " ")
        paragraphs = [p.get_text(" ", strip=True) for p in main.select("p")
                      if not p.find_parent(["figure", "aside"]) and len(p.get_text().split()) >= 20]
        output.extend(chunk("OpenStax • " + title, " ".join(paragraphs), "Textbook section", url))
    return output


def scholarly(topic):
    # Search broadly so topics outside the small OpenStax index can still use
    # scholarly material. OpenAlex ranks its search results; the quiz engine
    # then checks each candidate fact against the requested topic.
    params = {"search": topic, "per_page": 25,
              "filter": "language:en,has_abstract:true,is_retracted:false",
              "select": "id,doi,title,type,primary_location,abstract_inverted_index"}
    key = os.getenv("OPENALEX_API_KEY")
    headers = {**HEADERS, **({"Authorization": f"Bearer {key}"} if key else {})}
    response = requests.get("https://api.openalex.org/works", params=params, headers=headers, timeout=(5, 15))
    response.raise_for_status()
    passages = []
    works = []
    topic_words = set(normalize(topic).split()) - {"and", "of", "the", "to", "in", "for"}
    for work in response.json().get("results", []):
        if work.get("type") not in {"article", "review", "book-chapter", "book", "proceedings-article"}:
            continue
        title = work.get("title")
        abstract_index = work.get("abstract_inverted_index") or {}
        if not title or not abstract_index:
            continue
        pairs = [(position, token) for token, positions in abstract_index.items() for position in positions]
        abstract = " ".join(word for _, word in sorted(pairs))
        url = work.get("doi") or work.get("id") or ""
        if urlparse(url).scheme != "https" or urlparse(url).hostname not in {"doi.org", "openalex.org"}:
            continue
        title_overlap = len(topic_words & set(normalize(title).split()))
        abstract_overlap = len(topic_words & set(normalize(abstract).split()))
        # Retain broad search results when the abstract itself discusses the
        # topic, even if the publication title uses a neighboring term.
        if topic_words and max(title_overlap, abstract_overlap) == 0:
            continue
        works.append((title_overlap, abstract_overlap, title, abstract, url))
    works.sort(key=lambda item: (item[0], item[1]), reverse=True)
    for _, _, title, abstract, url in works:
        passages.extend(chunk(title, abstract, "Published abstract", url))
    return passages


def research(topic):
    if not 3 <= len(topic.strip()) <= 120:
        raise ValueError("Enter a topic between 3 and 120 characters.")
    passages = []
    with ThreadPoolExecutor(max_workers=2) as executor:
        jobs = [executor.submit(provider, topic) for provider in (textbook, scholarly)]
        for job in jobs:
            try:
                passages.extend(job.result())
            except (requests.RequestException, ValueError):
                continue
    if not passages:
        raise GenerationError("No suitable online sources responded for this topic. Try a more specific academic topic or upload a document.")
    return passages

