"""Optional local FLAN-T5 check of generated answers."""
import json
import os
from pathlib import Path
from threading import Lock


class CheckpointReviewer:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.manifest = self.directory / "checkpoint_manifest.json"
        self.available = self.manifest.is_file()
        self.lock = Lock()
        self.model = None

    def load(self):
        # Keep PyTorch optional for installations that disable the second check.
        import torch
        from safetensors.torch import load_file
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

        config = json.loads(self.manifest.read_text(encoding="utf-8"))
        source = os.getenv("QUIZ_FLAN_BASE_MODEL") or config["base_model"]
        tokenizer = AutoTokenizer.from_pretrained(source)
        model = AutoModelForSeq2SeqLM.from_pretrained(source, use_safetensors=True)
        weights = load_file(str(self.directory / config["checkpoint"]))
        parameters = model.state_dict()
        if not weights or any(name not in parameters or parameters[name].shape != value.shape
                              for name, value in weights.items()):
            raise ValueError("The review checkpoint does not match its base model.")
        model.load_state_dict(weights, strict=False)
        labels = [tokenizer.encode(letter, add_special_tokens=False) for letter in "ABCD"]
        if not all(len(tokens) == 1 for tokens in labels):
            raise ValueError("The tokenizer cannot score the four answer labels.")
        self.choice_ids = [tokens[0] for tokens in labels]
        self.max_tokens = config["max_input_tokens"]
        self.order_count = config.get("answer_orders", 1)
        if self.order_count not in {1, 4}:
            raise ValueError("Unsupported answer-order configuration.")
        self.tokenizer = tokenizer
        self.torch = torch
        self.model = model.eval()

    def annotate(self, items):
        with self.lock:
            if self.model is None:
                self.load()
            votes = None
            for shift in range(self.order_count):
                prompts = []
                for item in items:
                    rotated = item["options"][shift:] + item["options"][:shift]
                    options = "\n".join(f"{label}. {value}" for label, value in zip("ABCD", rotated))
                    prompts.append(f"Read the passage and answer with A, B, C, or D.\nQuestion: {item['question']}\n"
                                   f"{options}\nPassage: {item['quote']}\nAnswer:")
                batch = self.tokenizer(prompts, return_tensors="pt", padding=True, truncation=True,
                                       max_length=self.max_tokens)
                start = self.torch.full((len(items), 1), self.model.config.decoder_start_token_id,
                                        dtype=self.torch.long)
                with self.torch.inference_mode():
                    logits = self.model(**batch, decoder_input_ids=start, use_cache=False).logits[:, 0, self.choice_ids]
                    scores = logits.softmax(dim=-1).roll(shift, dims=-1)
                votes = scores if votes is None else votes + scores
            predictions = votes.argmax(dim=1).tolist()
        for item, predicted in zip(items, predictions):
            item["checkpoint_review"] = {
                "answer": predicted, "status": "agree" if predicted == item["answer"] else "disagree"
            }

