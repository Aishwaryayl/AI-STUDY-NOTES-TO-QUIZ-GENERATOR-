# Dataset inventory

| Source | Use | Download |
|---|---|---|
| Ai2 SciQ | Primary MCQ benchmark. Original question, supporting text, correct option, and three distractors. Official train is used for corpus exploration, validation selects retrieval, and held-out test measures it. CC BY-NC 3.0 per publisher. | [Dataset card](https://huggingface.co/datasets/allenai/sciq) · [Train Parquet](https://huggingface.co/datasets/allenai/sciq/resolve/main/data/train-00000-of-00001.parquet) · [Validation Parquet](https://huggingface.co/datasets/allenai/sciq/resolve/main/data/validation-00000-of-00001.parquet) · [Test Parquet](https://huggingface.co/datasets/allenai/sciq/resolve/main/data/test-00000-of-00001.parquet) |
| OpenStax Introduction to Computer Science | Real university-level source text for document-mode use and selected topic retrieval. See the book for its CC BY-NC-SA 4.0 attribution and restrictions. The full book exceeds the app's page limit, so select a section or chapter. | [Official textbook](https://openstax.org/details/books/introduction-computer-science) · [Direct PDF](https://assets.openstax.org/oscms-prodcms/media/documents/Introduction_To_Computer_Science_-_WEB.pdf) |
| Stanford SQuAD 1.1 | Optional alternative for extractive answer evaluation. It has paragraph, question, and answer-span labels. It has no distractor labels and is not used in the notebook scores. | [Official dataset page](https://rajpurkar.github.io/SQuAD-explorer/) · [Train JSON](https://rajpurkar.github.io/SQuAD-explorer/dataset/train-v1.1.json) · [Public dev JSON](https://rajpurkar.github.io/SQuAD-explorer/dataset/dev-v1.1.json) |
| OpenAlex Works | On-demand topic search over published works with available English abstracts. Retrieved text may carry publisher rights. | [Search API](https://help.openalex.org/api/searching/) · [Sample query](https://api.openalex.org/works?search=database%20management%20systems&per_page=3) |

SciQ is supplied by AI2. See the [dataset paper](https://arxiv.org/abs/1707.06209) and the dataset card before redistribution. The raw Parquet files preserve the publisher's splits. The cleaned files retain only usable four-choice items with explicit support. Identical normalized support does not cross splits. The application never draws prewritten quiz questions from these files.

The PDF and Word verification documents in the project are original computing notes created for repeatable parser tests. They are separate from the benchmark data.


### Original file integrity

SHA-256 for the three publisher files in this package:

- Train: 19644360954006d06e9ad3df07bdb34f8535c081b831d48f604603c713ac167
- Validation: 455dd9f1d725cd3ebcce369799a2fbbdbbfecf51ab84a86d56ba3370dc847b8a
- Test: 3a719356a29b127fc54ef3c7f51a034db4bd105d5717215e8c85d2aa58d60667
