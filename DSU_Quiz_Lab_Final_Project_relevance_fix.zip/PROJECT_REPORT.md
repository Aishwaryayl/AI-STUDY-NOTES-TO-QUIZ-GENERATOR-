# DSU Quiz Lab project report

## Objective

Help university students practise with quizzes grounded in their study files or retrieved academic sources, and keep their quiz records private to their accounts.

## System design

1. A student registers and signs in. Flask validates forms and manages sessions. SQLite persists accounts, quizzes and attempts, with each record scoped to its owner.
2. The student uploads a searchable PDF or DOCX, or enters an academic topic. The app extracts document passages or retrieves OpenStax and OpenAlex material.
3. A passage ranker selects source text. Qwen2.5, running through Ollama, generates a structured quiz. The app validates choice distinctness and identifies source evidence.
4. The fine-tuned FLAN-T5 checkpoint independently checks each generated answer from the question, choices and evidence. Its agreement or disagreement is saved with the item. Students see the check after submission.
5. The app grades against the stored key and shows the score, answers, citations and history. Verification disagreements are visible for review.

## Model development results

SciQ supplies source passages, multiple-choice questions and answers. The notebook fine-tunes the final FLAN-T5 decoder block and normalization layer on 240 MCQ examples and 48 question-generation examples. A validation set of 96 questions selects the epoch and answer-order scoring method. The selected checkpoint scores 4 choice order(s) per question.

| Model | Original 48 questions | Fresh held-out 160 questions |
|---|---:|---:|
| Pretrained FLAN-T5 Small | 30/48 (62.5%) | 109/160 (68.1%) |
| Previous fine-tuned checkpoint | 37/48 (77.1%) | 119/160 (74.4%) |
| Expanded fine-tuning run | 46/48 (95.8%) | 150/160 (93.8%) |

Both test groups come from SciQ's official test split. The fresh group excludes exact passages used for the initial 48-question comparison and uses one example per normalized support passage. The results measure multiple-choice answer selection on those samples. They do not measure the factual accuracy of generated quizzes. Question-generation metrics are reported separately in the notebook.

The application ships with the expanded checkpoint.

## Verification

The notebook executed and reloaded its exported checkpoint. Application tests covered authentication, document extraction, scoring, history, and record isolation. Live Ollama checks of the quiz generator produced and graded PDF, DOCX, and online-topic quizzes. The checkpoint integration check used three recorded live-generated questions and ran the actual trained model through the application route. It verified that second-model checks are persisted and shown only after submission. See evaluation/checkpoint_app_test.json for the recorded outcomes. Docker execution and visual browser inspection were outside the verified scope.

## Dataset and source material

The primary training benchmark is [Ai2 SciQ](https://huggingface.co/datasets/allenai/sciq). The app retrieves selected textbook sections from [OpenStax](https://openstax.org/details/books/introduction-computer-science) and scholarly abstracts from [OpenAlex](https://help.openalex.org/api/). The wordmark and campus rendering are credited in the application README.

## Algorithm comparison

The notebook compares Logistic Regression, Decision Tree, Random Forest and Gradient Boosting on identical split samples. The validation-selected method is **Random Forest**, with **95.0%** fresh-test accuracy. See evaluation/algorithm_comparison.csv and evaluation/fresh_algorithm_metrics.csv for the results.
